//
//  RCDataManager.h
//  iYunSheng
//
//  Created by yygt on 2017/8/2.
//  Copyright © 2017年 Beijing Yinrun Guangtong Technology Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RongIMKit/RongIMKit.h"

/**
 *  RCDataManager类为核心管理融云一切逻辑的类，包括充当用户信息提供者的代理，同步好友列表，同步群组列表，登录融云服务器，刷新角标badgeValue等等
 */
@interface RCDataManager : NSObject <RCIMUserInfoDataSource,RCIMGroupInfoDataSource,RCIMReceiveMessageDelegate>

///是否关闭消息声音提示
@property (nonatomic, assign) BOOL disableMessageAlertSound;
///是否关闭本地通知
@property (nonatomic, assign) BOOL disableMessageNotificaiton;
///发送/输入状态(仅单聊)
@property (nonatomic, assign) BOOL enableTypingStatus;
///发送/回执(单聊、群聊、讨论组)
@property (nonatomic, assign) BOOL enabledReadReceiptStatus;
///聊天界面头像方形/原型
//globalMessageAvatarStyle

///单例类
+ (instancetype)sharedManager;

- (void)setDeviceToken:(NSData *)deviceToken;

///登录
- (void)loginRongCloudWithUserInfo:(RCUserInfo *)userInfo withToken:(NSString *)token;

///退出
- (void)logOut;

///通过userid得到RCUserInfo
- (void)getUserInfoWithUserId:(NSString*)userId completion:(void (^)(RCUserInfo*))completion;

///好友中是否有这个userid
- (BOOL)hasTheFriendWithUserId:(NSString *)userId;

///群组中是否有这个groupid
- (BOOL)hasTheGroupWithGroupId:(NSString *)groupId;

///从服务器同步好友列表
- (void)syncFriendList:(void (^)(NSMutableArray * friends,BOOL isSuccess))completion;

/// 从服务器同步群组列表
- (void)syncGroupList:(void (^)(NSMutableArray * groups,BOOL isSuccess))completion;

/// 批量从服务器获取个人信息
- (void)syncUsersInfoList:(NSArray *)user_ids completion:(void (^)(NSMutableArray * friends,BOOL isSuccess))completion;

/// 从本地数据库同步未关注人列表
- (void)syncOtherUserList:(void (^)(NSMutableArray * others,BOOL isSuccess))completion;

///刷新badge
- (void)refreshBadgeValue;

///根据用户参数的id获取当前用户的name
- (NSString *)currentNameWithUserId:(NSString *)userId;

///根据用户参数的id（userId）获取RCUserInfo
- (RCUserInfo *)currentUserInfoWithUserId:(NSString *)userId;

///根据群组的id（groupId）获取RCGroup
- (RCGroup *)currentGroupInfoWithGroupId:(NSString *)groupId;

///收到消息推送
- (void)rcloudReceiveRemoteNotification:(NSDictionary *)userInfo;

/// 屏蔽某个会话的消息
- (void)setConversationNotificationStatus:(RCConversationType)conversationType targetId:(NSString *)targetId isBlocked:(BOOL)isBlocked success:(void(^)(RCConversationNotificationStatus nStatus))successBlock error:(void(^)(RCErrorCode status))errorBlock;

///清空某个会话的聊天记录
- (BOOL)clearMessages:(RCConversationType)conversationType targetId:(NSString *)targetId;

///从本地存储中删除会话
- (BOOL)removeConversation:(RCConversationType)conversationType
                  targetId:(NSString *)targetId;

///清空融云缓存包括聊天记录
-(void)clearRCIMCache;

///聊天室：加入已存在聊天室
- (void)joinExistChatRoom:(NSString *)targetId
             messageCount:(int)messageCount
                  success:(void (^)())successBlock
                    error:(void (^)(RCErrorCode status))errorBlock;

///退出聊天室
- (void)quitChatRoom:(NSString *)targetId
             success:(void (^)())successBlock
               error:(void (^)(RCErrorCode status))errorBlock;

///获取聊天室的信息（包含部分成员信息和当前聊天室中的成员总数）
- (void)getChatRoomInfo:(NSString *)targetId
                  count:(int)count
                  order:(RCChatRoomMemberOrder)order
                success:(void (^)(RCChatRoomInfo *chatRoomInfo))successBlock
                  error:(void (^)(RCErrorCode status))errorBlock;

@end
