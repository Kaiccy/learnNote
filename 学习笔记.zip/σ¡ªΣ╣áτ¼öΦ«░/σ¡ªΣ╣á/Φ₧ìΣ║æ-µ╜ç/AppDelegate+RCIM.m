//
//  AppDelegate+RCIM.m
//  iYunSheng
//
//  Created by 安潇 on 2017/8/2.
//  Copyright © 2017年 Beijing Yinrun Guangtong Technology Co., Ltd. All rights reserved.
//

#import "AppDelegate+RCIM.h"
#import "RCDataManager.h"

#define kRongCloudAppKey   @"mgb7ka1nmfjkg"

@implementation AppDelegate (RCIM)

-(void)registerRongClouldWithOptions:(NSDictionary *)launchOptions{
    
    // 初始化 SDK，传入 AppKey
    
    [[RCIM sharedRCIM] initWithAppKey:kRongCloudAppKey];
    [RCIM sharedRCIM].enableMessageAttachUserInfo = YES;
    [RCIM sharedRCIM].enablePersistentUserInfoCache = YES;
    
    
    //    设置用户信息提供者为 [RCDataManager shareManager]
    [RCIM sharedRCIM].userInfoDataSource = [RCDataManager sharedManager];
    //    设置群组信息提供者为 [RCDataManager shareManager]
    [RCIM sharedRCIM].groupInfoDataSource = [RCDataManager sharedManager];
    [RCIM sharedRCIM].receiveMessageDelegate = [RCDataManager sharedManager];
    //    [[RCIM sharedRCIM]registerMessageType:WMVideoMessage.class];
    
    [RCDataManager sharedManager].enableTypingStatus = YES;
    [RCDataManager sharedManager].enabledReadReceiptStatus = YES;
    
    // 注册推送 (极光已注册)
    
}

@end
