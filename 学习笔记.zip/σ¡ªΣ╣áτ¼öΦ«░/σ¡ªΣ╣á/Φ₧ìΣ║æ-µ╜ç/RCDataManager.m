//
//  RCDataManager.m
//  iYunSheng
//
//  Created by yygt on 2017/8/2.
//  Copyright © 2017年 Beijing Yinrun Guangtong Technology Co., Ltd. All rights reserved.
//

#import "RCDataManager.h"
#import "MainTabbarVC.h"
#import "JPUSHService.h"
#import "CoreDataManager.h"
#import "SesstionListVC.h"
#import "BaseNavVC.h"

#define kRCIMReceiveMessageUnReadFlag @"kRCIMReceiveMessageUnReadFlag"

@interface RCDataManager ()

@property (nonatomic, strong) NSMutableArray *friendsArrM;//好友数组
@property (nonatomic, strong) NSMutableArray *otherUserArrM;//未关注好友数组
@property (nonatomic, strong) NSMutableArray *groupsArrM; //群组数组

@end

@implementation RCDataManager

+ (instancetype)sharedManager
{
    static RCDataManager *manage = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manage = [[RCDataManager alloc] init];
    });
    return manage;
}

- (instancetype)init
{
    if (self = [super init]) {
        
        [RCIM sharedRCIM].userInfoDataSource = self;
        
        [RCIM sharedRCIM].groupInfoDataSource = self;
        
        [RCIM sharedRCIM].receiveMessageDelegate = self;
    }
    return self;
}

- (void)setDeviceToken:(NSData *)deviceToken{
    NSString *token =  [[[[deviceToken description] stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""]stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    [[RCIMClient sharedRCIMClient] setDeviceToken:token];
}

//是否关闭消息声音提示
- (void)setDisableMessageAlertSound:(BOOL)disableMessageAlertSound{
    _disableMessageAlertSound = disableMessageAlertSound;
    [RCIM sharedRCIM].disableMessageAlertSound = disableMessageAlertSound;
}
//是否关闭本地通知
- (void)setDisableMessageNotificaiton:(BOOL)disableMessageNotificaiton{
    _disableMessageNotificaiton = disableMessageNotificaiton;
    [RCIM sharedRCIM].disableMessageNotificaiton = disableMessageNotificaiton;
}
//发送/输入状态(仅单聊)
- (void)setEnableTypingStatus:(BOOL)enableTypingStatus{
    _enableTypingStatus = enableTypingStatus;
    [RCIM sharedRCIM].enableTypingStatus = enableTypingStatus;
}
//发送/回执(单聊、群聊、讨论组)
- (void)setEnabledReadReceiptStatus:(BOOL)enabledReadReceiptStatus{
    _enabledReadReceiptStatus = enabledReadReceiptStatus;
    if (enabledReadReceiptStatus) {
        [RCIM sharedRCIM].enabledReadReceiptConversationTypeList = @[@(ConversationType_DISCUSSION),@(ConversationType_PRIVATE),@(ConversationType_GROUP)];
    }
}

#pragma mark - loginRongCloud
- (void)loginRongCloudWithUserInfo:(RCUserInfo *)userInfo withToken:(NSString *)token{
    [[RCIM sharedRCIM] connectWithToken:token success:^(NSString *userId) {
        [RCIM sharedRCIM].globalNavigationBarTintColor = [UIColor redColor];
        AXLog(@"登陆成功。当前登录的用户ID：%@", userId);
        [[RCIM sharedRCIM] setCurrentUserInfo:userInfo];
        //同步好友列表
        [self syncFriendList:^(NSMutableArray *friends, BOOL isSuccess) {
            self.friendsArrM = friends;
            // 使用本地数据库---未关注的人---打开会话时更新
            // FileCacheManager---已关注的人---及时更新(弃用----采用融云自带缓存)
            
            [self updateRCIMUserCache];
        }];
        
        [[RCDataManager sharedManager] refreshBadgeValue];
        
        // 获取未关注好友数组
        [self syncOtherUserList:^(NSMutableArray *others, BOOL isSuccess) {
            self.otherUserArrM = others;
        }];
        
    } error:^(RCConnectErrorCode status) {
        AXLog(@"登陆的错误码为:%ld", (long)status);
    } tokenIncorrect:^{
        //token过期或者不正确。
        //如果设置了token有效期并且token过期，请重新请求您的服务器获取新的token
        //如果没有设置token有效期却提示token错误，请检查您客户端和服务器的appkey是否匹配，还有检查您获取token的流程。
        AXLog(@"token错误");
    }];
}

- (void)logOut{
    [[RCIMClient sharedRCIMClient] setReceiveMessageDelegate:nil object:nil];
    [[RCIMClient sharedRCIMClient] setRCConnectionStatusChangeDelegate:nil];
    // 断开与融云服务器的连接，并不再接收远程推送
    [[RCIM sharedRCIM] logout];
}

#pragma mark - 获取融云好友群组数据

#pragma mark - 刷新角标

- (void)refreshBadgeValue
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSInteger unreadMsgCount = (NSInteger)[[RCIMClient sharedRCIMClient] getUnreadCount:@[@(ConversationType_PRIVATE), @(ConversationType_GROUP),@(ConversationType_DISCUSSION),@(ConversationType_CUSTOMERSERVICE),@(ConversationType_SYSTEM)]];
        
        UIViewController *root = [UIApplication sharedApplication].delegate.window.rootViewController;
        if ([root isKindOfClass:[MainTabbarVC class]]) {
//            MainTabbarVC *main = (MainTabbarVC *)root;
//            UINavigationController *chatNav = main.viewControllers[0];
            
            if (unreadMsgCount == 0) {
//                chatNav.tabBarItem.badgeValue = nil;
                [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
                // 刷新首页消息红点
                
            }else{
//                chatNav.tabBarItem.badgeValue = [NSString stringWithFormat:@"%li",(long)unreadMsgCount];
                [[UIApplication sharedApplication] setApplicationIconBadgeNumber:unreadMsgCount];
                // 刷新首页消息红点
                
            }
            [NSNotificationCenter postNotification:kRCIMReceiveMessageUnReadFlag object:[NSString stringWithFormat:@"%ld",(long)unreadMsgCount]];
        }
        
    });
}

-(BOOL)hasTheFriendWithUserId:(NSString *)userId
{
    
    if (self.friendsArrM) {
        NSMutableArray *tempArray = [[NSMutableArray alloc]init];
        
        for (RCUserInfo *aUserInfo in self.friendsArrM) {
            [tempArray addObject:aUserInfo.userId];
        }
        
        if ([tempArray containsObject:userId]) {
            return YES;
        }
    }
    return NO;
}

- (BOOL)hasTheGroupWithGroupId:(NSString *)groupId
{
    AXLog(@"group-->%@<--", self.groupsArrM);
    if (self.groupsArrM.count) {
        NSMutableArray *tempArray = [[NSMutableArray alloc] init];
        for (RCGroup *aGroupInfo in self.groupsArrM) {
            [tempArray addObject:aGroupInfo.groupId];
        }
        if ([tempArray containsObject:groupId]) {
            return YES;
        }
    }
    return NO;
}


/**
 *  从服务器同步好友列表
 */
-(void)syncFriendList:(void (^)(NSMutableArray* friends,BOOL isSuccess))completion
{
    iYSUserInfoModel *user = [[UserInfoManager sharedManager]currentUserInfo];
    
    if ([[user log] Follows].count < 1) {
        
        return;
    }

    [self syncUsersInfoList:[[user log] Follows] completion:^(NSMutableArray *friends, BOOL isSuccess) {
        completion(friends,isSuccess);
    }];
}

/**
 *  批量从服务器获取个人信息
 */
- (void)syncUsersInfoList:(NSArray *)user_ids completion:(void (^)(NSMutableArray * friends,BOOL isSuccess))completion{
    NSDictionary *params = @{
                             @"method":kUserFriendsInfo_method,
                             @"token":[[UserInfoManager sharedManager]token],
                             @"user_id":user_ids
                             };
    [[iYSDataManager sharedManager] loadDataWithUrlString:kAPI_HEAD_URL params:params completionBlock:^(NSDictionary *object) {
        if ([object[@"success"] isEqualToString:@"true"]) {
            NSArray *arr = object[@"message"];
            NSMutableArray *arrM = [NSMutableArray array];
            [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSDictionary *dict = obj;
                NSString *userId = [dict objectForKey:@"user_id"];
                NSString *name = [dict objectForKey:@"nickname"];
                NSString *portraitUri = [dict objectForKey:@"headimg"];
                RCUserInfo *info = [[RCUserInfo alloc]initWithUserId:userId name:name portrait:portraitUri];
                [arrM addObject:info];
            }];
            
            completion(arrM,YES);
            
        }
    } mainTheadBlock:^{
        
    } toView:nil isShow:NO];
}


/**
 *  从服务器同步群组列表
 */
- (void)syncGroupList:(void (^)(NSMutableArray * groups,BOOL isSuccess))completion{

    completion(nil,NO);
    
}

/**
 从本地数据库同步未关注人列表
 */
- (void)syncOtherUserList:(void (^)(NSMutableArray *others,BOOL isSuccess))completion{
    NSArray *results = [[CoreDataManager sharedManager]fetchObjectWithRCUserInfo:nil];
    AXLog(@"%@",results);
    if (results.count > 0) {
        RCUser *user = [results firstObject];
        AXLog(@"%@==%@",user.name,user.portraitUri);
        NSMutableArray *arrM = [NSMutableArray arrayWithArray:results];
        completion(arrM,YES);
    }
}

#pragma mark - 根据userId获取RCUserInfo
- (RCUserInfo *)currentUserInfoWithUserId:(NSString *)userId{
    for (NSInteger i = 0; i<self.friendsArrM.count; i++) {
        RCUserInfo *aUser = self.friendsArrM[i];
        if ([userId isEqualToString:aUser.userId]) {
            return aUser;
        }
    }
    NSArray *results = [[CoreDataManager sharedManager]fetchObjectWithRCUserInfo:userId];
    if (self.otherUserArrM.count >= 1) {
        RCUser *user = [results firstObject];
        RCUserInfo *aUser = [[RCUserInfo alloc]initWithUserId:user.userId name:user.name portrait:user.portraitUri];
        return aUser;
    }
    for (NSInteger i = 0; i<self.otherUserArrM.count; i++) {
        RCUser *user = self.otherUserArrM[i];
        if ([userId isEqualToString:user.userId]) {
            RCUserInfo *aUser = [[RCUserInfo alloc]initWithUserId:user.userId name:user.name portrait:user.portraitUri];
            return aUser;
        }
    }
    return nil;
}

#pragma mark - 根据userId获取RCGroup
-(RCGroup *)currentGroupInfoWithGroupId:(NSString *)groupId{
//    for (NSInteger i = 0; i<self.groupsArrM.count; i++) {
//        RCGroup *aGroup = self.groupsArrM[i];
//        if ([groupId isEqualToString:aGroup.groupId]) {
//            return aGroup;
//        }
//    }
    return nil;
}
-(NSString *)currentNameWithUserId:(NSString *)userId{
    for (NSInteger i = 0; i < self.friendsArrM.count; i++) {
        RCUserInfo *aUser = self.friendsArrM[i];
        if ([userId isEqualToString:aUser.userId]) {
            AXLog(@"current ＝ %@",aUser.name);
            return aUser.name;
        }
    }
    for (NSInteger i = 0; i<self.otherUserArrM.count; i++) {
        RCUser *user = self.otherUserArrM[i];
        if ([userId isEqualToString:user.userId]) {
            RCUserInfo *aUser = [[RCUserInfo alloc]initWithUserId:user.userId name:user.name portrait:user.portraitUri];
            return aUser.name;
        }
    }
    return nil;
}

#pragma mark - RCIMUserInfoDataSource
- (void)getUserInfoWithUserId:(NSString*)userId completion:(void (^)(RCUserInfo*))completion
{
    //    AXLog(@"getUserInfoWithUserId ----- %@", userId);
    
    if (userId == nil || [userId length] == 0 )
    {
//        [self syncFriendList:^(NSMutableArray *friends, BOOL isSuccess) {
//            self.friendsArrM = friends;
//        }];
//        
//        completion(nil);
        return ;
    }
    AXLog(@"%@==%@",userId,[RCIM sharedRCIM].currentUserInfo.userId);
    if ([userId isEqualToString:[RCIM sharedRCIM].currentUserInfo.userId]) {
        RCUserInfo *myselfInfo = [[RCUserInfo alloc]initWithUserId:[RCIM sharedRCIM].currentUserInfo.userId name:[RCIM sharedRCIM].currentUserInfo.name portrait:[RCIM sharedRCIM].currentUserInfo.portraitUri];
        completion(myselfInfo);
        
    }
    //循环好友数组
    for (NSInteger i = 0; i < self.friendsArrM.count; i++) {
        RCUserInfo *aUser = self.friendsArrM[i];
        if ([userId isEqualToString:aUser.userId]) {
            completion(aUser);
            break;
        }
    }
    // 循环未关注数组
    for (NSInteger i = 0; i<self.otherUserArrM.count; i++) {
        RCUser *user = self.otherUserArrM[i];
        if ([userId isEqualToString:user.userId]) {
            RCUserInfo *aUser = [[RCUserInfo alloc]initWithUserId:user.userId name:user.name portrait:user.portraitUri];
            completion(aUser);
            break;
        }
    }
}

#pragma mark - update RCIM user cache
- (void)updateRCIMUserCache{
    [self.friendsArrM enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        RCUserInfo *user = obj;
        [[RCIM sharedRCIM] refreshUserInfoCache:user withUserId:user.userId];
    }];
}

#pragma mark - RCIMGroupInfoDataSource
- (void)getGroupInfoWithGroupId:(NSString *)groupId
                     completion:(void (^)(RCGroup *groupInfo))completion{
    for (NSInteger i = 0; i < self.groupsArrM.count; i++) {
        RCGroup *aGroup = self.groupsArrM[i];
        if ([groupId isEqualToString:aGroup.groupId]) {
            completion(aGroup);
            break;
        }
    }
}

#pragma mark - RCIMReceiveMessageDelegate

// 接收消息的回调方法
- (void)onRCIMReceiveMessage:(RCMessage *)message
                        left:(int)left{
    // 刷新角标
    [self refreshBadgeValue];
    
    // 查询本地是否有缓存
    if(![self hasTheFriendWithUserId:message.senderUserId]){
        
        if (![[CoreDataManager sharedManager] fetchObjectWithRCUserInfo:message.senderUserId]) {
            //向服务器请求发送者信息信息并缓存---更新self.otherUserArrM
            [self syncUsersInfoList:@[message.senderUserId] completion:^(NSMutableArray *friends, BOOL isSuccess) {
                RCUserInfo *info = [friends firstObject];
                
                [[CoreDataManager sharedManager]insertNewObjectWithRCUserInfo:info.userId name:info.name portraitUri:info.portraitUri completion:^(RCUser *user) {
                    AXLog(@"%@",user.portraitUri);
                    [self.otherUserArrM addObject:user];
                }];
                
            }];
        }
    }
    
}



// 当App处于后台时，接收到消息并弹出本地通知的回调方法
- (BOOL)onRCIMCustomLocalNotification:(RCMessage*)message
                      withSenderName:(NSString *)senderName{
    
    // 注意：用户/群组信息为空 -> 不弹出本地通知
    
    AXLog(@"%@",message.senderUserId);
    
    return NO;
    
}

// 当App处于前台时，接收到消息并播放提示音的回调方法
-(BOOL)onRCIMCustomAlertSound:(RCMessage*)message{
    
    return NO;
}

// 被撤回的消息ID
- (void)onRCIMMessageRecalled:(long)messageId{
    
}


#pragma mark - 消息推送处理
- (void)rcloudReceiveRemoteNotification:(NSDictionary *)userInfo {
    // 统计推送打开率
    
    [[RCIMClient sharedRCIMClient] recordRemoteNotificationEvent:userInfo];
    
    // 获取融云推送服务扩展字段
    // nil 表示该启动事件不包含来自融云的推送服务
    
    NSDictionary *pushServiceData = [[RCIMClient sharedRCIMClient] getPushExtraFromRemoteNotification:userInfo];
    if (pushServiceData) {
        AXLog(@"该远程推送包含来自融云的推送服务");
        // userInfo为远程推送的内容
        
    } else {
        AXLog(@"该远程推送不包含来自融云的推送服务");
        
    }
    
    NSDictionary *msgDic = [userInfo objectForKey:@"rc"];
    AXLog(@"%@",msgDic);
    // 存在即融云本地消息
    if (msgDic) {
        if ([[UserInfoManager sharedManager]isLogin]) {
            SesstionListVC *vc = [[SesstionListVC alloc]init];
            vc.title = @"消息列表";
            //显示聊天列表界面
            BaseNavVC *nav = [UIApplication sharedApplication].keyWindow.rootViewController.childViewControllers[[AXUtils getMainTabbarSelectedIndex]];
            [nav pushViewController:vc animated:YES];
        }
    }

}

-(void)clearRCIMCache{
//    [[RCIM sharedRCIM] clearUserInfoCache];
    [[RCIM sharedRCIM] clearGroupInfoCache];
    [[RCIM sharedRCIM] clearGroupUserInfoCache];
    // 清除所有会话类型的聊天记录
    [[RCIMClient sharedRCIMClient]clearConversations:@[@(ConversationType_DISCUSSION),@(ConversationType_PRIVATE),@(ConversationType_APPSERVICE),@(ConversationType_PUBLICSERVICE),@(ConversationType_GROUP),@(ConversationType_SYSTEM),@(ConversationType_CUSTOMERSERVICE)]];
}

/// 屏蔽某个会话的消息
- (void)setConversationNotificationStatus:(RCConversationType)conversationType targetId:(NSString *)targetId isBlocked:(BOOL)isBlocked success:(void(^)(RCConversationNotificationStatus nStatus))successBlock error:(void(^)(RCErrorCode status))errorBlock{
    //
    [[RCIMClient sharedRCIMClient] setConversationNotificationStatus:conversationType targetId:targetId isBlocked:isBlocked success:^(RCConversationNotificationStatus nStatus) {
        successBlock(nStatus);
    } error:^(RCErrorCode status) {
        errorBlock(status);
    }];
}

///清空某个会话的聊天记录
- (BOOL)clearMessages:(RCConversationType)conversationType targetId:(NSString *)targetId{
    //先把数据库中的清除
    return [[RCIMClient sharedRCIMClient] clearMessages:conversationType targetId:targetId];
}

///从本地存储中删除会话
- (BOOL)removeConversation:(RCConversationType)conversationType
                  targetId:(NSString *)targetId{
    return [[RCIMClient sharedRCIMClient] removeConversation:conversationType targetId:targetId];
}

///聊天室：加入已存在聊天室
- (void)joinExistChatRoom:(NSString *)targetId
             messageCount:(int)messageCount
                  success:(void (^)())successBlock
                    error:(void (^)(RCErrorCode status))errorBlock{
    
    [[RCIMClient sharedRCIMClient] joinExistChatRoom:targetId messageCount:messageCount success:^{
        if (successBlock) {
            successBlock();
        }
    } error:^(RCErrorCode status) {
        if (errorBlock) {
            errorBlock(status);
        }
    }];
}

///退出聊天室
- (void)quitChatRoom:(NSString *)targetId
             success:(void (^)())successBlock
               error:(void (^)(RCErrorCode status))errorBlock{
    
    [[RCIMClient sharedRCIMClient] quitChatRoom:targetId success:^{
        if (successBlock) {
            successBlock();
        }
    } error:^(RCErrorCode status) {
        if (errorBlock) {
            errorBlock(status);
        }
    }];
}

///获取聊天室的信息（包含部分成员信息和当前聊天室中的成员总数）
- (void)getChatRoomInfo:(NSString *)targetId
                  count:(int)count
                  order:(RCChatRoomMemberOrder)order
                success:(void (^)(RCChatRoomInfo *chatRoomInfo))successBlock
                  error:(void (^)(RCErrorCode status))errorBlock{
    
    [[RCIMClient sharedRCIMClient] getChatRoomInfo:targetId count:count order:order success:^(RCChatRoomInfo *chatRoomInfo) {
        if (successBlock) {
            successBlock(chatRoomInfo);
        }
    } error:^(RCErrorCode status) {
        if (errorBlock) {
            errorBlock(status);
        }
    }];
}

/*
 //会话类型。PR 指单聊、 DS 指讨论组、 GRP 指群组、 CS 指客服、SYS 指系统会话、 MC 指应用内公众服务、 MP 指跨应用公众服务
 NSString *cType = [msgDic objectForKey:@"cType"];
 
 //消息发送者的用户 ID
 // NSString *fId = [msgDic objectForKey:@"fId"];
 
 //消息类型，参考融云消息类型表.消息标志；可自定义消息类型
 // NSString *oName = [msgDic objectForKey:@"oName"];
 
 //Target ID
 NSString *targetId = [msgDic objectForKey:@"tId"];
 
 // 跳转聊天界面
 SessionSingleVC *chat = [[SessionSingleVC alloc]init];
 
 //设置会话的类型，如单聊、讨论组、群聊、聊天室、客服、公众服务会话等,为转换后的值
 chat.conversationType = [cType integerValue];
 
 //设置会话的目标会话ID。（单聊、客服、公众服务会话为对方的ID，讨论组、群聊、聊天室为会话的ID）
 chat.targetId = targetId;
 
 //设置聊天会话界面要显示的标题
 chat.title = @"想显示的会话标题";
 
 //显示聊天会话界面
 BaseNavVC *nav = [UIApplication sharedApplication].keyWindow.rootViewController.childViewControllers[[AXUtils getMainTabbarSelectedIndex]];
 [nav pushViewController:chat animated:YES];
 */

@end
